<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        if (!is_string($text) || strlen($text) === 0){
            return '';
        }

        $chars = str_split($text);
        $encodedText = '';
        $substitutionReferential = $this->makeSubstitutionReferential();

        foreach ($chars as $char) {
            $isUpper = ctype_upper($char);
            $encodedChar = $this->getEncoding(strtolower($char), $substitutionReferential);
            $encodedText .= ($isUpper) ? strtoupper($encodedChar) : $encodedChar;
        }

        return $encodedText;
    }

    private function makeSubstitutionReferential()
    {
        $rules = array();
        foreach ($this->substitutions as $substitution){
            $rules[ strtolower( $substitution[0] ) ] = strtolower( $substitution[1] );
            $rules[ strtolower( $substitution[1] ) ] = strtolower( $substitution[0] );
        }

        return $rules;
    }

    private function getEncoding($char, array $substitutionRules)
    {
        $encodedChar = $substitutionRules[$char];

        if ($encodedChar === null){
            return $char;
        }
        return $encodedChar;
    }
}