<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        if (!is_string($text) || strlen($text) === 0){
            return '';
        }

        $chars = str_split($text);
        $encodedText = '';
        $runTimeReferential = array();
        $lookupChars = str_split(self::CHARACTERS);

        foreach ($chars as $char) {
            $encodedChar = $this->getEncodingByReferential($char, $runTimeReferential);

            if ($encodedChar === null){
                $runTimeReferential[$char] = $this->encodeChar($char, $lookupChars);
                $encodedChar = $runTimeReferential[$char];
            }

            $encodedText .= $encodedChar;
        }

        return $encodedText;
    }

    private function encodeChar($char, $lookupChars)
    {
        $key = array_search($char, $lookupChars);
        if ( !is_int($key) ) {
            return $char;
        }

        $charOffset = $key + $this->offset;

        if ($charOffset > (strlen(self::CHARACTERS) - 1) ) {
            $charOffset = $charOffset - strlen(self::CHARACTERS);
        }

        return self::CHARACTERS[$charOffset];
    }

    private function getEncodingByReferential($target, array $localStorage)
    {
        if (array_key_exists($target, $localStorage)){
            return $localStorage[$target];
        }
        return null;
    }
}